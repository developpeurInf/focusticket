import { Ticket } from "@/types/ticket";
import { User } from "@/types/user";
import { Asset, AssetType } from "@/types/asset";
import * as XLSX from 'xlsx';

// Convert tickets data to CSV format
export const ticketsToCSV = (tickets: Ticket[]): string => {
  if (tickets.length === 0) return '';
  
  // Define CSV headers based on ticket properties in French
  const headers = [
    'N° Ticket', 
    'Titre', 
    'Statut', 
    'Date d\'ouverture', 
    'Priorité',
    'Demandeur',
    'Attribué à',
    'Équipement / Module',
    'Numéro de série',
    'Site',
    'Action(s)',
    'Date de résolution',
    'Commentaire'
  ].join(',');
  
  // Map each ticket to a CSV row
  const rows = tickets.map(ticket => {
    return [
      ticket.ticketNumber || ticket.id,
      `"${ticket.subject.replace(/"/g, '""')}"`, // Escape quotes in subject
      ticket.status,
      new Date(ticket.createdAt).toLocaleDateString('fr-FR'),
      ticket.priority,
      ticket.createdBy,
      ticket.assignedTo || 'Non attribué',
      `"${ticket.equipment.replace(/"/g, '""')}"`,
      ticket.serialNumber,
      ticket.site,
      `"${ticket.actions.replace(/"/g, '""')}"`,
      ticket.resolvedAt ? new Date(ticket.resolvedAt).toLocaleDateString('fr-FR') : '-',
      `"${ticket.comment.replace(/"/g, '""')}"`
    ].join(',');
  });
  
  // Combine headers and rows
  return [headers, ...rows].join('\n');
};

// Convert assets data to CSV format
export const assetsToCSV = (assets: Asset[]): string => {
  if (assets.length === 0) return '';
  
  // Define CSV headers in French
  const headers = [
    'ID',
    'Nom/Produit',
    'Numéro de série',
    'Type',
    'Projet',
    'Fabricant',
    'Modèle',
    'Site',
    'Statut'
  ].join(',');
  
  // Map each asset to a CSV row
  const rows = assets.map(asset => {
    // Map status/type for translation if needed
    return [
      asset.id,
      `"${asset.name.replace(/"/g, '""')}"`,
      `"${asset.serialNumber.replace(/"/g, '""')}"`,
      asset.type,
      `"${(asset.projet || '').replace(/"/g, '""')}"`,
      `"${(asset.fabricant || '').replace(/"/g, '""')}"`,
      `"${(asset.modele || '').replace(/"/g, '""')}"`,
      asset.site,
      asset.status
    ].join(',');
  });
  
  // Combine headers and rows
  return [headers, ...rows].join('\n');
};

// Convert users data to CSV format
export const usersToCSV = (users: User[]): string => {
  if (users.length === 0) return '';
  
  // Define CSV headers based on user properties
  const headers = [
    'ID',
    'Name',
    'Email',
    'Role',
    'Department',
    'Status',
    'Last Active',
    'Tickets Assigned',
    'Tickets Resolved'
  ].join(',');
  
  // Map each user to a CSV row
  const rows = users.map(user => {
    return [
      user.id,
      `"${user.name.replace(/"/g, '""')}"`,
      user.email,
      user.role,
      user.department || 'N/A',
      user.status,
      user.lastActive ? new Date(user.lastActive).toLocaleString() : 'N/A',
      user.ticketsAssigned || 0,
      user.ticketsResolved || 0
    ].join(',');
  });
  
  // Combine headers and rows
  return [headers, ...rows].join('\n');
};

// Create and download a CSV file with BOM for Excel compatibility
export const downloadCSV = (data: string, filename: string): void => {
  // Add UTF-8 BOM (\uFEFF) so Excel recognizes accents correctly
  const BOM = "\uFEFF";
  const blob = new Blob([BOM + data], { type: 'text/csv;charset=utf-8;' });
  
  // Create a download URL for the blob
  const url = URL.createObjectURL(blob);
  
  // Create a temporary anchor element to trigger the download
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  // Append to the document, trigger the download, and clean up
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

const parseFrenchDate = (val: any): string | null => {
  if (!val || val === '?' || val === '-') return null;
  
  // Try Excel numeric format first
  const numVal = Number(val);
  if (!isNaN(numVal) && numVal > 10000 && numVal < 100000) {
    // Excel dates are number of days since Jan 1 1900, adjusting for 1970 epoch
    const date = new Date((numVal - 25569) * 86400 * 1000);
    if (!isNaN(date.getTime())) return date.toISOString();
  }
  
  // Try DD/MM/YY or DD/MM/YYYY
  const str = String(val).trim();
  const parts = str.split(/[-/]/);
  
  if (parts.length === 3) {
    let day = parseInt(parts[0], 10);
    let month = parseInt(parts[1], 10);
    let year = parseInt(parts[2], 10);
    
    // Swap if YYYY-MM-DD
    if (day > 1000 && year < 32) {
      const tempDay = year;
      year = day;
      day = tempDay;
    }
    
    if (year >= 0 && year < 100) year += 2000;
    
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      const d = new Date(year, month - 1, day, 12, 0, 0); // Use 12:00 to avoid UTC negative shift bugs
      if (!isNaN(d.getTime())) return d.toISOString();
    }
  }

  // Fallback to JS standard parsing
  const d = new Date(str);
  if (!isNaN(d.getTime())) return d.toISOString();

  return null;
};

// Advanced parser using XLSX to support Excel and CSV files regardless of empty grid offsets
export const processImportedTickets = async (file: File): Promise<Ticket[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) return resolve([]);
        
        // Read file using Excel processor
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Extract multi-dimensional array mapping rows
        const json = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1, blankrows: false });
        
        let headerRowIndex = -1;
        let columnMap: Record<string, number> = {};
        
        // Find the valid header row containing columns we need
        for (let i = 0; i < json.length; i++) {
          const row = json[i];
          if (!row || !Array.isArray(row)) continue;
          
          const rowStr = row.join(' ').toLowerCase();
          // Detect headers
          if (rowStr.includes('ticket') || rowStr.includes('titre') || rowStr.includes('statut')) {
            headerRowIndex = i;
            // Build absolute column map ignoring left grid shifts
            row.forEach((col: any, idx: number) => {
              if (typeof col === 'string') {
                const key = col.toLowerCase().trim();
                // We use includes for fuzzy matching
                if (key.includes('ticket')) columnMap['id'] = idx;
                else if (key.includes('titre')) columnMap['subject'] = idx;
                else if (key.includes('statut')) columnMap['status'] = idx;
                else if (key.includes('ouverture')) columnMap['createdAt'] = idx;
                else if (key.includes('priorit')) columnMap['priority'] = idx;
                else if (key.includes('demandeur')) columnMap['createdBy'] = idx;
                else if (key.includes('attribu')) columnMap['assignedTo'] = idx;
                else if (key.includes('quipement')) columnMap['equipment'] = idx;
                else if (key.includes('série') || key.includes('serie')) columnMap['serialNumber'] = idx;
                else if (key.includes('site')) columnMap['site'] = idx;
                else if (key.includes('action')) columnMap['actions'] = idx;
                else if (key.includes('résolution') || key.includes('resolu')) columnMap['resolvedAt'] = idx;
                else if (key.includes('desc')) columnMap['description'] = idx;
                else if (key.includes('comment')) columnMap['comment'] = idx;
              }
            });
            break;
          }
        }
        
        if (headerRowIndex === -1) {
          console.warn("Could not find headers in Excel/CSV");
          return resolve([]);
        }

        const tickets: Ticket[] = [];
        
        // Parse the tickets row by row
        for (let i = headerRowIndex + 1; i < json.length; i++) {
          const row = json[i];
          if (!row || row.length === 0) continue;
          
          const getVal = (key: string) => {
            if (columnMap[key] !== undefined) {
              const val = row[columnMap[key]];
              if (val === undefined || val === null) return '';
              return String(val).trim();
            }
            return '';
          };
          
          const id = getVal('id');
          if (!id) continue;

          // Convert localized French statuses to internal tags
          const rawStatus = getVal('status').toLowerCase();
          const mappedStatus = (rawStatus.includes('résolu') || rawStatus.includes('clos') || rawStatus.includes('cloturé') || rawStatus.includes('cloture')) ? 'closed' 
                             : (rawStatus.includes('en cours')) ? 'in-progress' 
                             : 'open';
                             
          const rawPriority = getVal('priority').toLowerCase();
          const mappedPriority = rawPriority.includes('haut') ? 'high'
                               : rawPriority.includes('critique') ? 'critical'
                               : rawPriority.includes('bas') ? 'low'
                               : 'medium';

          const parsedCreatedAt = parseFrenchDate(getVal('createdAt'));
          const parsedResolvedAt = parseFrenchDate(getVal('resolvedAt'));

          tickets.push({
            id: id,
            ticketNumber: id.startsWith('R-') ? id : 'R-IMPORT',
            subject: getVal('subject') || 'Sans titre',
            description: getVal('description') || getVal('subject') || 'Importé depuis Excel',
            status: mappedStatus as any,
            createdAt: parsedCreatedAt || new Date().toISOString(),
            priority: mappedPriority as any,
            createdBy: getVal('createdBy') || 'Utilisateur inconnu',
            assignedTo: getVal('assignedTo') || null,
            equipment: getVal('equipment') || 'N/A',
            serialNumber: getVal('serialNumber') || 'N/A',
            site: getVal('site') || 'N/A',
            actions: getVal('actions') || '',
            resolvedAt: parsedResolvedAt,
            comment: getVal('comment') || '',
            dueDate: undefined,
            category: 'other'
          });
        }
        
        resolve(tickets);
      } catch (err) {
        console.error("Error parsing file", err);
        resolve([]);
      }
    };
    reader.readAsBinaryString(file);
  });
};

// Parser for Asset Inventory (Parc Informatique)
export const processImportedAssets = async (file: File): Promise<Asset[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) return resolve([]);
        
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const json = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1, blankrows: false });
        
        let headerRowIndex = -1;
        let columnMap: Record<string, number> = {};
        
        for (let i = 0; i < json.length; i++) {
          const row = json[i];
          if (!row || !Array.isArray(row)) continue;
          
          const rowStr = row.join(' ').toLowerCase();
          // Detect asset headers (French and English)
          if (
            rowStr.includes('série') || rowStr.includes('serie') ||
            rowStr.includes('serial') || rowStr.includes('serail') ||
            rowStr.includes('produit') || rowStr.includes('product') ||
            rowStr.includes('fabricant') || rowStr.includes('manufact') || rowStr.includes('manif')
          ) {
            headerRowIndex = i;
            row.forEach((col: any, idx: number) => {
              if (typeof col === 'string') {
                const key = col.toLowerCase().trim();
                // Map columns - French and English
                if (key.includes('série') || key.includes('serie') || key.includes('serial') || key.includes('serail') || key.includes('number')) columnMap['serialNumber'] = idx;
                else if (key.includes('projet') || key.includes('project')) columnMap['project'] = idx;
                else if (key.includes('fabricant') || key.includes('manufact') || key.includes('manif')) columnMap['manufacturer'] = idx;
                else if (key.includes('produit') || key.includes('product')) columnMap['name'] = idx;
                else if (key.includes('type')) columnMap['type'] = idx;
                else if (key.includes('modèle') || key.includes('modele') || key.includes('model')) columnMap['model'] = idx;
                else if (key.includes('site')) columnMap['location'] = idx;
                else if (key.includes('status') || key.includes('statut')) columnMap['status'] = idx;
              }
            });
            break;
          }
        }
        
        if (headerRowIndex === -1) {
          console.warn("Could not find headers for assets in Excel/CSV");
          return resolve([]);
        }

        const assets: Asset[] = [];
        
        for (let i = headerRowIndex + 1; i < json.length; i++) {
          const row = json[i];
          if (!row || row.length === 0) continue;
          
          const getVal = (key: string) => {
            if (columnMap[key] !== undefined) {
              const val = row[columnMap[key]];
              if (val === undefined || val === null) return '';
              return String(val).trim();
            }
            return '';
          };
          
          const serial = getVal('serialNumber');
          // Don't skip '0' — only skip truly empty values
          if (serial === '' && columnMap['serialNumber'] !== undefined) continue;
          if (columnMap['serialNumber'] === undefined) continue;

          // Convert to AssetType — handles real types from the user's Excel
          const rawType = getVal('type').toLowerCase();
          let type: AssetType = 'peripheral';
          if (rawType.includes('serveur power') || rawType.includes('server power')) type = 'server';
          else if (rawType.includes('serveur') || rawType.includes('server')) type = 'server';
          else if (rawType.includes('robot')) type = 'robot';
          else if (rawType.includes('hmc')) type = 'hmc';
          else if (rawType.includes('sw san') || rawType.includes('san')) type = 'san';
          else if (rawType.includes('pc') || rawType.includes('ordinateur') || rawType.includes('laptop') || rawType.includes('computer')) type = 'computer';
          else if (rawType.includes('écran') || rawType.includes('ecran') || rawType.includes('monitor')) type = 'monitor';
          else if (rawType.includes('imprimante') || rawType.includes('printer')) type = 'printer';
          else if (rawType.includes('reseau') || rawType.includes('réseau') || rawType.includes('routeur') || rawType.includes('network')) type = 'network';
          else if (rawType.includes('logiciel') || rawType.includes('software')) type = 'software';
          
          // Map status
          const rawStatus = getVal('status').toLowerCase();
          let status: Asset['status'] = 'available'; // Set default 
          if (rawStatus.includes('service') || rawStatus.includes('in-use') || rawStatus.includes('utilisé')) status = 'in-use';
          else if (rawStatus.includes('réparation') || rawStatus.includes('repair') || rawStatus.includes('panne')) status = 'under-repair';
          else if (rawStatus.includes('retiré') || rawStatus.includes('retired') || rawStatus.includes('mort')) status = 'retired';

          assets.push({
            id: `AST-${Math.floor(Math.random() * 100000)}`,
            serialNumber: serial,
            name: getVal('name') || 'Actif Inconnu',
            projet: getVal('project') || '',
            fabricant: getVal('manufacturer') || 'Inconnu',
            produit: getVal('name') || '',
            type: type,
            modele: getVal('model') || 'Non spécifié',
            site: getVal('location') || 'Non spécifié',
            status: status as any
          });
        }
        
        resolve(assets);
      } catch (err) {
        console.error("Error parsing asset file", err);
        resolve([]);
      }
    };
    reader.readAsBinaryString(file);
  });
};


