import { Asset } from "@/types/asset";
import axios from "axios";

const API_URL = `/api`;

export const getAssets = async (): Promise<Asset[]> => {
  try {
    const response = await axios.get(`${API_URL}/assets`);
    return response.data.map((a: any) => ({
      id: a.id,
      name: a.name,
      type: a.type || 'computer',
      serialNumber: a.serialNumber || '',
      projet: a.projet || '',
      fabricant: a.fabricant || '',
      produit: a.produit || '',
      modele: a.modele || '',
      site: a.site || '',
      location: a.site || '',
      assignedTo: a.assignedToUser ? a.assignedToUser.name : '',
      purchaseDate: a.purchaseDate ? new Date(a.purchaseDate).toISOString().split('T')[0] : '',
      status: a.status === 'active' ? 'in-use' : a.status === 'broken' ? 'under-repair' : 'available',
    }));
  } catch (error) {
    console.error("Erreur API Assets:", error);
    return [];
  }
};

export const createAsset = async (assetData: Partial<Asset>): Promise<Asset> => {
  const response = await axios.post(`${API_URL}/assets`, assetData);
  return response.data;
};

export const updateAsset = async (id: string, assetData: Partial<Asset>): Promise<Asset> => {
  const response = await axios.put(`${API_URL}/assets/${id}`, assetData);
  return response.data;
};

export const deleteAsset = async (id: string): Promise<void> => {
  await axios.delete(`${API_URL}/assets/${id}`);
};
