export const mockTickets: any[] = [];
