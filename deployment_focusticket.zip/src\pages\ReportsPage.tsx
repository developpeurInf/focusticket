
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ReportDashboard from "@/components/reports/ReportDashboard";
import { useState } from "react";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Download, HelpCircle, Info, Settings2 } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function ReportsPage() {
  const { toast } = useToast();
  const [userRole, setUserRole] = useState<'admin' | 'agent' | 'customer'>('admin');

  const switchRole = (newRole: 'admin' | 'agent' | 'customer') => {
    setUserRole(newRole);
  };

  const exportAllReports = () => {
    toast({
      title: "Export Started",
      description: "Your report bundle is being prepared and will download shortly.",
    });
    
    // Simulate a download delay
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: "Your report bundle has been downloaded.",
      });
    }, 2000);
  };

  const openReportSettings = () => {
    toast({
      title: "Report Settings",
      description: "Report settings will be implemented in a future update.",
    });
  };

  const showHelp = () => {
    toast({
      title: "Help Center",
      description: "The reports help documentation will open in a new window.",
    });
  };

  return (
    <div className="flex h-screen w-full bg-background">
        <Sidebar userRole={userRole} />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          <Header userRole={userRole} onSwitchRole={switchRole} />
          
          <div className="flex-1 overflow-auto p-4 md:p-6">
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Rapports & Statistiques</h1>
                <p className="text-muted-foreground">
                  Visualisez les données de support et analysez les performances de votre équipe.
                </p>
              </div>
            </div>
            

            
            <ReportDashboard userRole={userRole} />
          </div>
        </main>
      </div>
  );
}
