import { Ticket } from "@/types/ticket";
import axios from "axios";

const API_URL = `/api`;

export const createTicket = async (ticket: any): Promise<Ticket> => {
  const response = await axios.post(`${API_URL}/tickets`, ticket);
  return response.data;
};

export const updateTicket = async (id: string, data: any): Promise<Ticket> => {
  const response = await axios.put(`${API_URL}/tickets/${id}`, data);
  return response.data;
};

export const deleteTicket = async (id: string): Promise<void> => {
  await axios.delete(`${API_URL}/tickets/${id}`);
};

export const updateTicketStatus = async (ticketId: string, newStatus: string): Promise<boolean> => {
  console.log(`Updating ticket ${ticketId} status to ${newStatus}`);
  // Simulate for now
  return true;
};

export const assignTicket = async (ticketId: string, agentId: string): Promise<boolean> => {
  console.log(`Assigning ticket ${ticketId} to agent ${agentId}`);
  return true;
};

export const getTickets = async (filters?: any): Promise<Ticket[]> => {
  try {
    const response = await axios.get(`${API_URL}/tickets`);
    return response.data.map((t: any) => {
      return {
        id: t.id,
        ticketNumber: t.ticketNumber || "R-XXXXXX",
        subject: t.title,
        description: t.description,
        // On garde les valeurs brutes pour que les filtres et badges fonctionnent
        status: t.status || 'open',
        priority: t.priority || 'medium',
        category: t.category || 'other',
        createdAt: t.createdAt,
        createdBy: t.creator ? t.creator.name : (t.createdBy || "Inconnu"),
        assignedTo: t.assignee ? t.assignee.name : (t.assignedTo || null),
        // Priorité : champ direct 'equipment', puis actif lié
        equipment: t.equipment || (t.asset ? (t.asset.produit || t.asset.name) : "-"),
        assetId: t.assetId,
        serialNumber: t.asset ? t.asset.serialNumber : (t.serialNumber || "-"),
        site: t.site || "-",
        actions: t.actions || "",
        resolvedAt: t.resolvedAt || null,
        comment: t.comment || ""
      };
    });
  } catch (error) {
    console.error("Erreur API:", error);
    return [];
  }
};

export const exportTickets = async (format: 'pdf' | 'excel', filters?: object): Promise<string> => {
  return `https://example.com/exports/tickets.${format}`;
};
