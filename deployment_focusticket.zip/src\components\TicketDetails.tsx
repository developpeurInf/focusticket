
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";
import { Ticket, Comment } from "@/types/ticket";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { addTicketComment } from "@/api/ticketService";
import { useToast } from "@/components/ui/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { addNotification } from "@/utils/notificationUtils";
import { mockUsers } from "@/data/mockUsers";

interface TicketDetailsProps {
  ticket: Ticket;
  comments?: Comment[];
  isLoadingComments?: boolean;
  onStatusChange: (newStatus: string) => void;
  onAssign: (agentId: string) => void;
  userRole?: 'admin' | 'agent' | 'customer';
}

export default function TicketDetails({ 
  ticket, 
  comments = [],
  isLoadingComments = false,
  onStatusChange, 
  onAssign,
  userRole = 'agent'
}: TicketDetailsProps) {
  const [response, setResponse] = useState("");
  const [status, setStatus] = useState<'open' | 'in-progress' | 'resolved' | 'closed'>(ticket.status);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const addCommentMutation = useMutation({
    mutationFn: ({ ticketId, content }: { ticketId: string, content: string }) => 
      addTicketComment(ticketId, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ticketComments', ticket.id] });
      addNotification("Nouveau Commentaire", `Un nouveau commentaire a été ajouté au ticket ${ticket.ticketNumber || ticket.id}.`, "Utilisateur");
      toast({
        title: "Commentaire ajouté",
        description: "Votre commentaire a été ajouté avec succès."
      });
      setResponse("");
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Échec de l'ajout",
        description: "Un problème est survenu lors de l'ajout de votre commentaire."
      });
    }
  });
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-500';
      case 'in-progress':
        return 'bg-yellow-500';
      case 'resolved':
        return 'bg-green-500';
      case 'closed':
        return 'bg-gray-500';
      default:
        return 'bg-blue-500';
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    }).format(date);
  };

  const handleStatusChange = (newStatus: string) => {
    // Cast the string to the correct type
    const typedStatus = newStatus as 'open' | 'in-progress' | 'resolved' | 'closed';
    setStatus(typedStatus);
    onStatusChange(newStatus);
  };

  const handleSubmitResponse = () => {
    if (!response.trim()) return;
    
    addCommentMutation.mutate({ 
      ticketId: ticket.id, 
      content: response 
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2 space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">#{ticket.id}</h3>
            <Badge className={getStatusColor(status)}>
              {status.replace('-', ' ')}
            </Badge>
          </div>
          <h2 className="text-2xl font-bold">{ticket.subject}</h2>
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span>Ouvert le : {formatDate(ticket.createdAt)}</span>
            <span>•</span>
            <span>Priorité : {ticket.priority}</span>
            <span>•</span>
            <span>Site : {ticket.site}</span>
          </div>
        </div>

        <Separator />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-semibold text-muted-foreground mb-1">Équipement / Module</h4>
            <p>{ticket.equipment}</p>
          </div>
          <div>
            <h4 className="font-semibold text-muted-foreground mb-1">Numéro de série</h4>
            <p>{ticket.serialNumber}</p>
          </div>
        </div>

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Description</h3>
          <p className="text-sm">{ticket.description}</p>
        </div>

        {ticket.actions && (
          <>
            <Separator />
            <div>
              <h3 className="font-semibold mb-2">Action(s) menée(s)</h3>
              <p className="text-sm border rounded-md p-3 bg-muted/30">{ticket.actions}</p>
            </div>
          </>
        )}

        {ticket.comment && (
          <>
            <Separator />
            <div>
              <h3 className="font-semibold mb-2">Commentaires / Notes</h3>
              <p className="text-sm italic">{ticket.comment}</p>
            </div>
          </>
        )}

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Historique de la conversation</h3>
          <ScrollArea className="h-[250px] rounded-md border p-4">
            {isLoadingComments ? (
              <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">Chargement des commentaires...</p>
              </div>
            ) : comments.length > 0 ? (
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <Avatar>
                      <AvatarImage src={comment.user.avatar} />
                      <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-sm">{comment.user.name}</h4>
                        <Badge variant="outline" className="text-xs">{comment.user.role}</Badge>
                        <span className="text-xs text-muted-foreground">{formatDate(comment.createdAt)}</span>
                      </div>
                      <p className="text-sm">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">Pas encore de commentaires</p>
              </div>
            )}
          </ScrollArea>
        </div>

        <div className="space-y-2">
          <Textarea 
            placeholder="Écrivez votre réponse ici..." 
            className="min-h-[100px]"
            value={response}
            onChange={(e) => setResponse(e.target.value)}
          />
          <div className="flex justify-end">
            <Button 
              onClick={handleSubmitResponse}
              disabled={addCommentMutation.isPending || !response.trim()}
            >
              {addCommentMutation.isPending ? "Envoi..." : "Envoyer la réponse"}
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {(userRole === 'admin' || userRole === 'agent') && (
          <>
            <div className="space-y-2 rounded-lg border p-4">
              <h3 className="font-semibold text-sm">Mettre à jour le statut</h3>
              <Select defaultValue={status} onValueChange={handleStatusChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un statut" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Statut</SelectLabel>
                    <SelectItem value="open">Ouvert</SelectItem>
                    <SelectItem value="in-progress">En cours</SelectItem>
                    <SelectItem value="resolved">Résolu</SelectItem>
                    <SelectItem value="closed">Clos</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 rounded-lg border p-4">
              <h3 className="font-semibold text-sm">Attribuer le ticket</h3>
              <Select onValueChange={onAssign}>
                <SelectTrigger>
                  <SelectValue placeholder={ticket.assignedTo || "Choisir un agent"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Intervenants</SelectLabel>
                    <SelectItem value="none">Aucun</SelectItem>
                    {mockUsers.filter(u => u.role === 'intervenant').map(user => (
                      <SelectItem key={user.id} value={user.name}>{user.name}</SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </>
        )}

        <div className="space-y-2 rounded-lg border p-4">
          <h3 className="font-semibold text-sm">Informations du ticket</h3>
          <dl className="space-y-3 text-sm">
            <div className="flex flex-col">
              <dt className="text-muted-foreground font-medium mb-1">Demandeur :</dt>
              <dd className="font-medium bg-secondary/30 px-2 py-1 rounded">{ticket.createdBy}</dd>
            </div>
            <div className="flex flex-col">
              <dt className="text-muted-foreground font-medium mb-1">Attribué à :</dt>
              <dd>{ticket.assignedTo || "Non attribué"}</dd>
            </div>
            <div className="flex flex-col">
              <dt className="text-muted-foreground font-medium mb-1">Ouvert le :</dt>
              <dd>{formatDate(ticket.createdAt)}</dd>
            </div>
            {ticket.dueDate && (
              <div className="flex flex-col">
                <dt className="text-muted-foreground font-medium mb-1">Échéance SLA :</dt>
                <dd className={
                  (() => {
                    if (ticket.status === 'resolved' || ticket.status === 'closed') return "text-green-600 font-medium";
                    const diff = new Date(ticket.dueDate).getTime() - new Date().getTime();
                    if (diff < 0) return "text-red-600 font-bold";
                    if (diff < 24 * 60 * 60 * 1000) return "text-orange-500 font-semibold";
                    return "text-blue-600 font-medium";
                  })()
                }>
                  {formatDate(ticket.dueDate)}
                </dd>
              </div>
            )}
            {ticket.resolvedAt && (
              <div className="flex flex-col">
                <dt className="text-muted-foreground font-medium mb-1">Résolu le :</dt>
                <dd className="text-green-600 font-semibold">{formatDate(ticket.resolvedAt)}</dd>
              </div>
            )}
            <div className="flex flex-col pt-2 border-t mt-2">
              <dt className="text-muted-foreground font-medium mb-1">Site :</dt>
              <dd>{ticket.site}</dd>
            </div>
          </dl>
        </div>

        <div className="space-y-2 rounded-lg border p-4">
          <h3 className="font-semibold">Export</h3>
          <div className="grid grid-cols-2 gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.open(`/api/tickets/export/pdf/${ticket.id}`, '_blank')}
            >
              PDF
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.open(`/api/tickets/export/excel/${ticket.id}`, '_blank')}
            >
              Excel
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
