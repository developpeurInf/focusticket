import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  Filter, 
  SearchIcon, 
  SlidersHorizontal,
  Upload,
  PlusCircle,
  Info,
  Activity
} from "lucide-react";
import TicketDetails from "@/components/TicketDetails";
import CreateTicketForm from "./CreateTicketForm";
import { Ticket } from "@/types/ticket";
import { useToast } from "@/components/ui/use-toast";
import { ticketsToCSV, downloadCSV, processImportedTickets } from "@/utils/exportUtils";
import { getTickets, deleteTicket, createTicket, updateTicket } from "@/data/ticketService";
import { Edit, Trash2, CheckCircle2, XCircle } from "lucide-react";
import { addNotification } from "@/utils/notificationUtils";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

interface TicketListProps {
  userRole: 'admin' | 'agent' | 'customer';
  initialStatusFilter?: string;
}
export default function TicketList({ userRole, initialStatusFilter = "" }: TicketListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [allTickets, setAllTickets] = useState<Ticket[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [readMoreContent, setReadMoreContent] = useState<{title: string, text: string} | null>(null);

  const loadTickets = () => {
    getTickets().then(data => {
      setAllTickets(data);
      setSelectedIds([]); // Clear selection on reload
    }).catch(() => setAllTickets([]));
  };

  useEffect(() => {
    loadTickets();
    window.addEventListener('tickets-updated', loadTickets);
    return () => window.removeEventListener('tickets-updated', loadTickets);
  }, []);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [priorityFilter, setPriorityFilter] = useState<string[]>([]);
  const [editingTicket, setEditingTicket] = useState<Ticket | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (initialStatusFilter === "all" || initialStatusFilter === "") {
      setStatusFilter([]);
    } else if (initialStatusFilter === "assigned") {
      setStatusFilter([]); // Géré par initialTickets
    } else {
      setStatusFilter([initialStatusFilter]);
    }
  }, [initialStatusFilter]);

  const initialTickets = useMemo(() => {
    if (userRole === 'customer') {
      return allTickets.filter(ticket => ticket.createdBy === 'current-user');
    } else if (userRole === 'agent') {
      if (initialStatusFilter === "assigned") {
        return allTickets.filter(ticket => ticket.assignedTo === 'current-user');
      }
      return allTickets.filter(ticket => 
        ticket.assignedTo === 'current-user' || 
        ticket.status === 'open'
      );
    }
    return allTickets;
  }, [userRole, initialStatusFilter, allTickets]);

  const filteredTickets = useMemo(() => {
    return initialTickets.filter(ticket => {
      const matchesSearch = 
        searchQuery === "" || 
        ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = 
        statusFilter.length === 0 || 
        statusFilter.includes(ticket.status);
      
      const matchesPriority = 
        priorityFilter.length === 0 || 
        priorityFilter.includes(ticket.priority);
      
      const matchesCategory = 
        categoryFilter.length === 0 || 
        categoryFilter.includes(ticket.category);
      
      return matchesSearch && matchesStatus && matchesPriority && matchesCategory;
    });
  }, [initialTickets, searchQuery, statusFilter, priorityFilter, categoryFilter]);

  const handleStatusToggle = (value: string) => {
    setStatusFilter(prev => 
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    );
  };

  const handlePriorityToggle = (value: string) => {
    setPriorityFilter(prev => 
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    );
  };

  const handleCategoryToggle = (value: string) => {
    setCategoryFilter(prev => 
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    );
  };

  const clearAllFilters = () => {
    setStatusFilter([]);
    setPriorityFilter([]);
    setCategoryFilter([]);
    setSearchQuery("");
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'open':
        return 'default';
      case 'in-progress':
        return 'secondary';
      case 'resolved':
        return 'success';
      case 'closed':
        return 'outline';
      default:
        return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
      case 'Ouvert':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'resolved':
      case 'closed':
      case 'Clôturé':
      case 'Clos':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityBadgeVariant = (priority: string) => {
    switch (priority) {
      case 'low':
        return { bg: 'bg-green-100', text: 'text-green-800' };
      case 'medium':
        return { bg: 'bg-blue-100', text: 'text-blue-800' };
      case 'high':
        return { bg: 'bg-orange-100', text: 'text-orange-800' };
      case 'critical':
        return { bg: 'bg-red-100', text: 'text-red-800' };
      default:
        return { bg: 'bg-gray-100', text: 'text-gray-800' };
    }
  };

  const handleStatusChange = (newStatus: string) => {
    if (selectedTicket) {
      toast({
        title: "Statut mis à jour",
        description: `Le ticket ${selectedTicket.id} a été mis à jour vers ${newStatus}`,
      });
    }
  };

  const handleAssign = (agentId: string) => {
    if (selectedTicket) {
      toast({
        title: "Ticket assigné",
        description: `Le ticket ${selectedTicket.id} a été assigné à l'intervenant`,
      });
    }
  };

  const handleExportCSV = () => {
    const csvData = ticketsToCSV(filteredTickets);
    const filename = `tickets-export-${new Date().toISOString().split('T')[0]}.csv`;
    downloadCSV(csvData, filename);
    
    toast({
      title: "Exportation réussie",
      description: `${filteredTickets.length} tickets exportés vers ${filename}`,
    });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const parsedTickets = await processImportedTickets(file);
      
      if (parsedTickets.length > 0) {
        toast({
          title: "Importation en cours...",
          description: `Enregistrement de ${parsedTickets.length} tickets dans PostgreSQL. Veuillez patienter...`
        });
        
        let successCount = 0;
        let failCount = 0;
        
        // Persister chaque ticket en base
        for (const t of parsedTickets) {
          try {
            const statusMap: Record<string, string> = { 
              'Ouvert': 'open', 'ouvert': 'open',
              'En cours': 'in-progress', 'en cours': 'in-progress',
              'Résolu': 'closed', 'résolu': 'closed',
              'Clos': 'closed', 'clos': 'closed',
              'Clôturé': 'closed', 'clôturé': 'closed',
              'Cloturé': 'closed', 'cloturé': 'closed',
              'closed': 'closed', 'open': 'open'
            };
            const priorityMap: Record<string, string> = { 'Basse': 'low', 'Moyenne': 'medium', 'Haute': 'high', 'Critique': 'critical', 'Urgent': 'critical' };
  
            await createTicket({
              title: t.subject,
              subject: t.subject,
              description: t.description,
              status: statusMap[t.status] || t.status || 'open',
              priority: priorityMap[t.priority] || t.priority || 'medium',
              category: t.category,
              createdBy: t.createdBy,
              assignedTo: t.assignedTo,
              equipment: t.equipment,
              serialNumber: t.serialNumber,  // Pour liaison automatique actif
              ticketNumber: t.id,            // Pour préserver le N° Excel (R-000036)
              site: t.site,
              comment: t.comment,
              actions: t.actions,
              resolvedAt: t.resolvedAt,
              createdAt: t.createdAt
            } as any);
            successCount++;
          } catch (error) {
            console.error(`Erreur import ticket ${t.id}:`, error);
            failCount++;
          }
        }
        
        // Rafraîchir la liste complète depuis la base
        loadTickets();
        
        if (failCount === 0) {
          toast({
            title: "Import réussi",
            description: `${successCount} tickets importés et sauvegardés avec succès.`,
          });
        } else {
          toast({
            title: "Import terminé avec erreurs",
            description: `${successCount} importés, ${failCount} échecs (probablement des doublons).`,
            variant: "destructive"
          });
        }
      } else {
        toast({
          title: "Échec de l'import",
          description: "Aucun ticket valide trouvé.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Import error", error);
      toast({
        title: "Erreur persistante",
        description: "Un problème est survenu lors de l'enregistrement PostgreSQL.",
        variant: "destructive",
      });
    }
    
    // Reset input
    e.target.value = '';
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <CardTitle>Tickets</CardTitle>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative flex-grow md:flex-grow-0 md:w-64">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Chercher des tickets..."
                className="pl-8"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                <DropdownMenuLabel>Filtrer par statut</DropdownMenuLabel>
                <DropdownMenuCheckboxItem
                  checked={statusFilter.includes('Ouvert')}
                  onCheckedChange={() => handleStatusToggle('Ouvert')}
                >
                  Ouvert
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={statusFilter.includes('Clôturé')}
                  onCheckedChange={() => handleStatusToggle('Clôturé')}
                >
                  Clôturé
                </DropdownMenuCheckboxItem>

                <DropdownMenuSeparator />
                <DropdownMenuLabel>Filtrer par priorité</DropdownMenuLabel>
                <DropdownMenuCheckboxItem
                  checked={priorityFilter.includes('low')}
                  onCheckedChange={() => handlePriorityToggle('low')}
                >
                  Basse
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={priorityFilter.includes('medium')}
                  onCheckedChange={() => handlePriorityToggle('medium')}
                >
                  Moyenne
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={priorityFilter.includes('high')}
                  onCheckedChange={() => handlePriorityToggle('high')}
                >
                  Haute
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={priorityFilter.includes('critical')}
                  onCheckedChange={() => handlePriorityToggle('critical')}
                >
                  Critique
                </DropdownMenuCheckboxItem>

                <DropdownMenuSeparator />
                <DropdownMenuLabel>Filtrer par catégorie</DropdownMenuLabel>
                <DropdownMenuCheckboxItem
                  checked={categoryFilter.includes('hardware')}
                  onCheckedChange={() => handleCategoryToggle('hardware')}
                >
                  Matériel
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={categoryFilter.includes('software')}
                  onCheckedChange={() => handleCategoryToggle('software')}
                >
                  Logiciel
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={categoryFilter.includes('network')}
                  onCheckedChange={() => handleCategoryToggle('network')}
                >
                  Réseau
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={categoryFilter.includes('account')}
                  onCheckedChange={() => handleCategoryToggle('account')}
                >
                  Compte
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={categoryFilter.includes('other')}
                  onCheckedChange={() => handleCategoryToggle('other')}
                >
                  Autre
                </DropdownMenuCheckboxItem>

                <DropdownMenuSeparator />
                <div className="p-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={clearAllFilters}
                  >
                    Effacer les filtres
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" size="icon">
              <SlidersHorizontal className="h-4 w-4" />
            </Button>

            <div className="relative">
              <input 
                type="file" 
                accept=".csv, .xlsx, .xls" 
                onChange={handleImport} 
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                title="Importer des tickets (Excel/CSV)"
              />
              <Button variant="outline" size="icon">
                <Upload className="h-4 w-4" />
              </Button>
            </div>

            {selectedIds.length > 0 && (
              <Button 
                variant="destructive" 
                className="gap-2"
                onClick={async () => {
                  if (confirm(`Voulez-vous supprimer les ${selectedIds.length} tickets sélectionnés ?`)) {
                    for (const id of selectedIds) {
                      await deleteTicket(id);
                    }
                    toast({ title: "Suppression réussie", description: `${selectedIds.length} tickets ont été supprimés.` });
                    loadTickets();
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
                Supprimer ({selectedIds.length})
              </Button>
            )}

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <PlusCircle className="h-4 w-4" />
                  Ajouter un ticket
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Ajouter un nouveau ticket</DialogTitle>
                  <DialogDescription>
                    Veuillez remplir les informations pour ouvrir un dossier d'assistance.
                  </DialogDescription>
                </DialogHeader>
                <CreateTicketForm onSuccess={() => setIsCreateDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-xl border shadow-sm overflow-hidden border-t-4 border-t-primary bg-card">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="hover:bg-transparent text-[11px] font-bold uppercase tracking-wider text-muted-foreground bg-muted/30">
                <TableHead className="w-[40px] px-4">
                  <Checkbox 
                    checked={filteredTickets.length > 0 && selectedIds.length === filteredTickets.length}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedIds(filteredTickets.map(t => t.id));
                      } else {
                        setSelectedIds([]);
                      }
                    }}
                  />
                </TableHead>
                <TableHead className="whitespace-nowrap px-2">N° Ticket</TableHead>
                <TableHead className="whitespace-nowrap px-2 min-w-[150px]">Titre</TableHead>
                <TableHead className="whitespace-nowrap px-2">Statut</TableHead>
                <TableHead className="whitespace-nowrap px-2">Priorité</TableHead>
                <TableHead className="whitespace-nowrap px-2">Demandeur</TableHead>
                <TableHead className="whitespace-nowrap px-2">Attribué à</TableHead>
                <TableHead className="whitespace-nowrap px-2">Équipement</TableHead>
                <TableHead className="whitespace-nowrap px-2">N° Série</TableHead>
                <TableHead className="whitespace-nowrap px-2">Site</TableHead>
                <TableHead className="whitespace-nowrap px-2">Ouverture</TableHead>
                <TableHead className="whitespace-nowrap px-2">Clôture</TableHead>
                <TableHead className="whitespace-nowrap px-2">Intervention</TableHead>
                <TableHead className="whitespace-nowrap px-2">Commentaire</TableHead>
                <TableHead className="text-right sticky right-0 bg-muted/80 shadow-[-10px_0_10px_-10px_rgba(0,0,0,0.1)] px-4">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTickets.length > 0 ? (
                filteredTickets.map((ticket) => {
                  const statusInfo = (ticket.status === 'closed' || (ticket.status as any) === 'Résolu' || (ticket.status as any) === 'Clôturé') 
                    ? { label: 'CLÔTURÉ', color: 'bg-emerald-100 text-emerald-800 border-emerald-200', icon: <CheckCircle2 className="h-3 w-3" /> }
                    : (ticket.status === 'in-progress' || (ticket.status as any) === 'En cours')
                    ? { label: 'EN COURS', color: 'bg-amber-100 text-amber-800 border-amber-200', icon: <Activity className="h-3 w-3" /> }
                    : { label: 'OUVERT', color: 'bg-sky-100 text-sky-800 border-sky-200', icon: <XCircle className="h-3 w-3" /> };

                  return (
                  <TableRow 
                    key={ticket.id} 
                    className={cn(
                      "group cursor-pointer hover:bg-primary/5 transition-all duration-200 border-b border-border/50 hover:shadow-sm",
                      selectedIds.includes(ticket.id) && "bg-primary/5"
                    )}
                  >
                    <TableCell className="w-[40px] px-4" onClick={(e) => e.stopPropagation()}>
                      <Checkbox 
                        checked={selectedIds.includes(ticket.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedIds(prev => [...prev, ticket.id]);
                          } else {
                            setSelectedIds(prev => prev.filter(id => id !== ticket.id));
                          }
                        }}
                      />
                    </TableCell>
                    <TableCell className="font-mono text-[11px] whitespace-nowrap px-2 font-bold text-muted-foreground">{ticket.ticketNumber}</TableCell>
                    <TableCell 
                      className="min-w-[150px] font-semibold text-sm px-2 cursor-pointer hover:text-primary transition-colors"
                      onClick={() => setReadMoreContent({ title: "Titre & Description", text: ticket.description || "Pas de description supplémentaire." })}
                    >
                      {ticket.subject}
                    </TableCell>
                    <TableCell className="px-2">
                      <Badge variant="outline" className={cn("font-bold px-2 py-0.5 uppercase text-[9px] tracking-tighter whitespace-nowrap", statusInfo.color)}>
                        <span className="flex items-center gap-1">{statusInfo.icon} {statusInfo.label}</span>
                      </Badge>
                    </TableCell>
                    <TableCell className="px-2">
                       <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full uppercase", 
                         ticket.priority === 'critical' || ticket.priority === 'high' ? "bg-red-50 text-red-700" : 
                         ticket.priority === 'low' ? "bg-slate-50 text-slate-600" : "bg-blue-50 text-blue-700"
                       )}>
                         {ticket.priority}
                       </span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-xs px-2">{ticket.createdBy}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs px-2 text-muted-foreground italic">{ticket.assignedTo || "-"}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs px-2 font-medium">{ticket.equipment || "-"}</TableCell>
                    <TableCell className="whitespace-nowrap text-[11px] px-2 font-mono">{ticket.serialNumber || "-"}</TableCell>
                    <TableCell className="whitespace-nowrap text-xs px-2">{ticket.site || "-"}</TableCell>
                    <TableCell className="whitespace-nowrap text-[11px] px-2">
                       {ticket.createdAt ? new Date(ticket.createdAt).toLocaleDateString('fr-FR') : "-"}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-[11px] px-2 font-bold text-emerald-600">
                      {ticket.resolvedAt ? new Date(ticket.resolvedAt).toLocaleDateString('fr-FR') : "-"}
                    </TableCell>
                    <TableCell 
                      className="max-w-[150px] truncate text-[11px] px-2 cursor-help italic hover:text-blue-600" 
                      onClick={(e) => {
                        e.stopPropagation();
                        setReadMoreContent({ title: "Détails de l'Intervention", text: ticket.actions || "Aucune intervention saisie." });
                      }}
                    >
                      {ticket.actions || "-"}
                    </TableCell>
                    <TableCell 
                      className="max-w-[150px] truncate text-[11px] px-2 cursor-help italic hover:text-emerald-600" 
                      onClick={(e) => {
                        e.stopPropagation();
                        setReadMoreContent({ title: "Commentaire Final", text: ticket.comment || "Aucun commentaire." });
                      }}
                    >
                      {ticket.comment || "-"}
                    </TableCell>
                    <TableCell className="text-right px-4 sticky right-0 bg-background/95 backdrop-blur-sm group-hover:bg-primary/5 transition-colors shadow-[-10px_0_10px_-10px_rgba(0,0,0,0.1)]">
                      <div className="flex justify-end gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-7 w-7 text-blue-600 hover:bg-blue-50"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingTicket(ticket);
                            setIsEditDialogOpen(true);
                          }}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-7 w-7 text-red-600 hover:bg-red-50"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (confirm("Voulez-vous vraiment supprimer ce ticket ?")) {
                              await deleteTicket(ticket.id);
                              addNotification("Ticket Supprimé", `Le ticket ${ticket.ticketNumber || ticket.id} a été supprimé definitivement.`, userRole);
                              window.dispatchEvent(new CustomEvent('tickets-updated'));
                              toast({ title: "Ticket supprimé" });
                            }
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={15} className="text-center py-12 text-muted-foreground italic">
                    Aucun ticket trouvé avec les filtres actuels
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl overflow-y-auto max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Modifier le Ticket {editingTicket?.ticketNumber}</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {editingTicket && (
              <CreateTicketForm 
                ticket={editingTicket} 
                onSuccess={() => {
                  setIsEditDialogOpen(false);
                  loadTickets(); // Recharger après modif
                }} 
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={!!readMoreContent} onOpenChange={(open) => !open && setReadMoreContent(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-blue-500" />
              {readMoreContent?.title}
            </DialogTitle>
          </DialogHeader>
          <div className="bg-muted/30 p-6 rounded-lg border border-border mt-2">
             <p className="whitespace-pre-wrap text-sm leading-relaxed text-foreground">
               {readMoreContent?.text}
             </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setReadMoreContent(null)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
